%%  signal generation

% global variables
fs = 44100;
t = 0:1/fs:3-1/fs;

% -------------- PART A1 ----------------
% sine signal 
f = 500;
S1 = sin(2*pi*f*t);
[OutSignal]=QuantiseAudio(S1,16,1, -1,0,3);
figure
plot(t,OutSignal);
figure
plotSpectrum(OutSignal,fs,1,1);
figure
spectrogram(S1,'yaxis');
%% 

% chirp signal
S2 = chirp(t,440,5,1320);
figure
plot(t,S2);
figure
plotSpectrum(S2,fs,1,1);
figure
spectrogram(S2,'yaxis');

% click track signal
%%Use Audacity for better results 
N=length(S1);
tempo = 120;
bps = tempo/60;
S3=zeros(1,N);
S3(1:fs/bps:N)=1;
figure
plot(t,S3);
figure
plotSpectrum(S3,fs,0,1);
figure
spectrogram(S3,'yaxis');
%%
%% 

% white gaussian noise signal
S4=wgn(1,l,50);
figure
plot(t,S4);
figure
plotSpectrum(S4,fs,1,1);
figure
spectrogram(S4,'yaxis');


% -------------- PART A2 ----------------
% load LP,HP and BP filters

load('filters.mat');

% sine signal 
S1LP = filter(LP,S1); % apply LP filter on sine signal
%...........
%...........



